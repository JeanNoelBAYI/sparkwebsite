document.addEventListener('DOMContentLoaded', function () {
  // Mobile nav toggle
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var isOpen = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  // Newsletter subscribe (footer) - demo only, no backend
  document.querySelectorAll('.footer-subscribe').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var input = form.querySelector('input');
      var btn = form.querySelector('button');
      if (input && input.value) {
        btn.textContent = 'Subscribed!';
        input.value = '';
        setTimeout(function () { btn.textContent = 'Subscribe'; }, 2500);
      }
    });
  });

  // Contact form - demo only, no backend
  var contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = contactForm.querySelector('button[type="submit"]');
      var original = btn.innerHTML;
      btn.textContent = 'Message sent — we\u2019ll be in touch';
      contactForm.reset();
      setTimeout(function () { btn.innerHTML = original; }, 3000);
    });
  }
});
